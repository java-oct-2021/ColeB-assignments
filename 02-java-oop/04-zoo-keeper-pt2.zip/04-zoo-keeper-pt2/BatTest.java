public class BatTest {
    
    public static void main(String[] args) {
        Bat bat = new Bat(300);
        bat.fly();
        bat.fly();
        bat.fly();
        bat.fly();
        bat.eatHumans();
        bat.eatHumans();
        bat.eatHumans();
        bat.eatHumans();
        bat.eatHumans();
        bat.eatHumans();
        bat.eatHumans();
        bat.attackTown();
        bat.attackTown();
        bat.attackTown();
        bat.attackTown();
    }
}
